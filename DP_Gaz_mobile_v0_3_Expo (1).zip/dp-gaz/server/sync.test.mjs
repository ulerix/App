import {Buffer} from 'node:buffer';
import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {createServer} from './server.mjs';
import {synchronize} from '../sync-core.mjs';
import {initializeSync,mobileStore} from '../sync-store.mjs';
const token='test-only-'+randomUUID();
async function fixture(t){
 const dir=mkdtempSync(join(tmpdir(),'dpgaz-'));
 let server;
 const start=async()=>{server=createServer({database:join(dir,'server.sqlite'),token});await new Promise(r=>server.listen(0,'127.0.0.1',r));};
 await start();
 const stop=()=>new Promise(r=>server.close(r));
 const request=async(path,options={})=>{const r=await fetch('http://127.0.0.1:'+server.address().port+path,{...options,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'}});const body=await r.json();if(!r.ok)throw new Error(r.status+' '+body.error);return body;};
 const clients=[];
 async function client(name){
  const db=new DatabaseSync(join(dir,name+'.sqlite'));
  db.exec('CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,kind TEXT,payload TEXT)');
  const adapter={execAsync:async s=>db.exec(s),runAsync:async(s,...args)=>db.prepare(s).run(...args),getFirstAsync:async(s,...args)=>db.prepare(s).get(...args),getAllAsync:async(s,...args)=>db.prepare(s).all(...args)};
  await initializeSync(adapter);const store=mobileStore(adapter),files=new Map();
  const c={store,files,db,request,readFile:async n=>{if(!files.has(n))throw new Error('fichier absent');return files.get(n);},writeFile:async(n,b)=>files.set(n,b),add:async(kind,value)=>adapter.runAsync('INSERT INTO records VALUES(?,?,?)',value.id,kind,JSON.stringify(value))};
  clients.push(c);return c;
 }
 t.after(async()=>{await stop();clients.forEach(c=>c.db.close());rmSync(dir,{recursive:true,force:true});});
 return {client,request,restart:async()=>{await stop();await start();},address:()=>server.address()};
}
const base=()=>({id:randomUUID(),created:new Date().toISOString()});
const customer=()=>({...base(),name:'Client test',number:randomUUID(),phone:'555-0100',address:'Adresse fictive'});
const job=clientId=>({...base(),clientId,title:'Génératrice',address:'Adresse fictive',status:'En cours'});
const note=jobId=>({...base(),jobId,type:'Note',text:'Essai',author:'Équipe'});

test('deux téléphones échangent clients, jobs, notes et PDF; reprise après redémarrage',async t=>{
 const f=await fixture(t),a=await f.client('a'),b=await f.client('b');
 const c=customer(),j=job(c.id),n=note(j.id),p={...note(j.id),type:'Document',mime:'application/pdf'};p.filename=p.id+'.pdf';
 for(const [kind,v] of [['clients',c],['jobs',j],['entries',n],['entries',p]])await a.add(kind,v);
 a.files.set(p.filename,Buffer.from('%PDF-fichier-test').toString('base64'));
 await synchronize(a);await f.restart();await synchronize(b);
 assert.equal(b.db.prepare('SELECT count(*) AS n FROM records').get().n,4);
 assert.equal(b.files.get(p.filename),a.files.get(p.filename));
 const reply=note(j.id);await b.add('entries',reply);await synchronize(b);await synchronize(a);
 assert.equal(a.db.prepare('SELECT count(*) AS n FROM records').get().n,5);
 assert.equal((await a.store.pending()).length,0);
});
test('réponse perdue après écriture : le réessai ne crée aucun doublon',async t=>{
 const f=await fixture(t),a=await f.client('a');await a.add('clients',customer());let once=true;
 await assert.rejects(synchronize({...a,request:async(path,options)=>{const r=await f.request(path,options);if(options?.method==='POST'&&once){once=false;throw new Error('coupure');}return r;}}),/coupure/);
 assert.equal((await a.store.pending()).length,1);await synchronize(a);
 assert.equal((await f.request('/records')).rows.length,1);assert.equal((await a.store.pending()).length,0);
});
test('coupure pendant téléchargement : curseur conservé, fichier récupéré au réessai',async t=>{
 const f=await fixture(t),a=await f.client('a'),b=await f.client('b');const c=customer(),j=job(c.id),p={...note(j.id),type:'Photo',mime:'image/jpeg'};p.filename=p.id+'.jpg';
 await a.add('clients',c);await a.add('jobs',j);await a.add('entries',p);a.files.set(p.filename,'YWJj');await synchronize(a);
 await assert.rejects(synchronize({...b,writeFile:async()=>{throw new Error('stockage plein');}}),/stockage plein/);
 assert.equal(await b.store.has(p.id),false);assert.equal(await b.store.getMeta('cursor'),'2');
 await synchronize(b);assert.equal(b.files.get(p.filename),'YWJj');assert.equal(await b.store.has(p.id),true);
});
test('refuse une réécriture avec le même identifiant et un parent absent',async t=>{
 const f=await fixture(t);const c=customer();const send=v=>f.request('/records',{method:'POST',body:JSON.stringify(v)});
 await send({kind:'clients',value:c});await assert.rejects(send({kind:'clients',value:{...c,name:'Autre'}}),/409/);
 await assert.rejects(send({kind:'jobs',value:job(randomUUID())}),/409/);
});
test('un autre espace ne reçoit pas les dossiers locaux',async t=>{
 const f=await fixture(t),a=await f.client('a');await a.store.setMeta('serverId','autre-espace');await a.add('clients',customer());
 await assert.rejects(synchronize(a),/autre espace/);assert.equal((await f.request('/records')).rows.length,0);
});
test('pagination et accès refusé sans code d’équipe',async t=>{
 const f=await fixture(t),a=await f.client('a'),b=await f.client('b');for(let i=0;i<105;i++)await a.add('clients',customer());
 await synchronize(a);await synchronize(b);assert.equal(b.db.prepare('SELECT count(*) AS n FROM records').get().n,105);
 const r=await fetch('http://127.0.0.1:'+f.address().port+'/records');assert.equal(r.status,401);
});

test('ajouts hors ligne des deux appareils : convergence sans perte',async t=>{
 const f=await fixture(t),a=await f.client('a'),b=await f.client('b');
 const c=customer(),j=job(c.id);await a.add('clients',c);await a.add('jobs',j);
 await synchronize(a);await synchronize(b);
 const na=note(j.id),nb=note(j.id);na.text='Ajout A hors ligne';nb.text='Ajout B hors ligne';
 await a.add('entries',na);await b.add('entries',nb);
 await assert.rejects(synchronize({...a,request:async()=>{throw new Error('hors ligne');}}),/hors ligne/);
 assert.equal((await a.store.pending()).length,1);
 await Promise.all([synchronize(a),synchronize(b)]);
 await synchronize(a);await synchronize(b);
 for(const device of [a,b]){
  assert.equal(await device.store.has(na.id),true);assert.equal(await device.store.has(nb.id),true);
  assert.equal((await device.store.pending()).length,0);
  assert.equal(device.db.prepare('SELECT count(*) AS n FROM records').get().n,4);
 }
});
test('JSON nul refusé proprement',async t=>{
 const f=await fixture(t);
 await assert.rejects(f.request('/records',{method:'POST',body:'null'}),/400/);
});
