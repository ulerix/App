import {Buffer} from 'node:buffer';
import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const MAX_FILE = 25 * 1024 * 1024;
const fail = (status, message) => Object.assign(new Error(message), { status });
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const canonical = value => JSON.stringify(Object.fromEntries(Object.entries(value).sort(([a],[b])=>a.localeCompare(b))));
function validate(kind, v) {
 if (!v || typeof v !== 'object' || Array.isArray(v) || !uuid.test(v.id) || !Number.isFinite(Date.parse(v.created))) throw fail(400,'Dossier invalide');
 const required = {clients:['name','number','phone','address'],jobs:['clientId','title','address','status'],entries:['jobId','type','text','author']}[kind];
 if (!required) throw fail(400,'Type inconnu');
 const allowed = new Set(['id','created',...required,...(kind==='entries'?['filename','mime']:[])]);
 if (Object.keys(v).some(k=>!allowed.has(k)) || Object.values(v).some(x=>typeof x!=='string'||x.length>20000) || required.some(k=>typeof v[k]!=='string')) throw fail(400,'Champs invalides');
 if(kind==='jobs'&&!uuid.test(v.clientId) || kind==='entries'&&!uuid.test(v.jobId)) throw fail(400,'Référence invalide');
 if(kind==='entries' && (!['Note','Photo','Document'].includes(v.type) || (v.type!=='Note' && !v.filename))) throw fail(400,'Pièce jointe invalide');
 if(v.filename && !new RegExp('^'+v.id+'(?:\\.[a-z0-9]{1,8})?$','i').test(v.filename)) throw fail(400,'Nom de fichier invalide');
}
export function createServer({database='dpgaz.sqlite',token}={}) {
 if(typeof token!=='string'||token.length<32) throw new Error('DPGAZ_TOKEN doit contenir au moins 32 caractères.');
 const db=new DatabaseSync(database);
 db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL); CREATE TABLE IF NOT EXISTS records(seq INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,attachment BLOB);');
 db.prepare('INSERT OR IGNORE INTO meta VALUES(?,?)').run('serverId',randomUUID());
 const serverId=db.prepare('SELECT value FROM meta WHERE key=?').get('serverId').value;
 const server=http.createServer(async(req,res)=>{
  const send=(code,body)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(body));};
  try {
   const a=Buffer.from(req.headers.authorization||''),b=Buffer.from('Bearer '+token);
   if(a.length!==b.length||!timingSafeEqual(a,b)) throw fail(401,'Accès refusé');
   const url=new URL(req.url,'http://localhost');
   if(req.method==='GET'&&url.pathname==='/identity') return send(200,{serverId});
   if(req.method==='GET'&&url.pathname==='/records') {
    const after=Number(url.searchParams.get('after')||0);
    if(!Number.isSafeInteger(after)||after<0) throw fail(400,'Curseur invalide');
    const rows=db.prepare('SELECT seq,kind,payload FROM records WHERE seq>? ORDER BY seq LIMIT 100').all(after);
    return send(200,{rows:rows.map(r=>({seq:r.seq,kind:r.kind,value:JSON.parse(r.payload)}))});
   }
   if(req.method==='GET'&&url.pathname.startsWith('/files/')) {
    const row=db.prepare('SELECT attachment FROM records WHERE id=?').get(url.pathname.slice(7));
    if(!row?.attachment) throw fail(404,'Fichier absent');
    return send(200,{base64:Buffer.from(row.attachment).toString('base64')});
   }
   if(req.method==='POST'&&url.pathname==='/records') {
    let size=0;const chunks=[];
    for await(const chunk of req){size+=chunk.length;if(size>36*1024*1024) throw fail(413,'Fichier trop volumineux');chunks.push(chunk);}
    let body;try{body=JSON.parse(Buffer.concat(chunks).toString());}catch{throw fail(400,'JSON invalide');}
    if(!body || typeof body!=='object' || Array.isArray(body)) throw fail(400,'Objet JSON requis');
    const {kind,value,file}=body;validate(kind,value);
    let attachment=null;
    if(value.filename){
     if(typeof file!=='string'||file.length%4!==0||!/^[A-Za-z0-9+/]*={0,2}$/.test(file)) throw fail(400,'Contenu du fichier invalide');
     attachment=Buffer.from(file,'base64');if(attachment.length>MAX_FILE) throw fail(413,'Fichier trop volumineux');
    } else if(file!==undefined) throw fail(400,'Fichier inattendu');
    const payload=canonical(value),existing=db.prepare('SELECT * FROM records WHERE id=?').get(value.id);
    if(existing){
     if(existing.kind!==kind||existing.payload!==payload||Boolean(existing.attachment)!==Boolean(attachment)||(attachment&&!Buffer.from(existing.attachment).equals(attachment))) throw fail(409,'Identifiant déjà utilisé pour un autre contenu');
     return send(200,{id:value.id,seq:existing.seq});
    }
    const parent=kind==='jobs'?['clients',value.clientId]:kind==='entries'?['jobs',value.jobId]:null;
    if(parent&&!db.prepare('SELECT id FROM records WHERE kind=? AND id=?').get(...parent)) throw fail(409,'Dossier parent manquant');
    const result=db.prepare('INSERT INTO records(id,kind,payload,attachment) VALUES(?,?,?,?)').run(value.id,kind,payload,attachment);
    return send(201,{id:value.id,seq:Number(result.lastInsertRowid)});
   }
   throw fail(404,'Route introuvable');
  }catch(error){send(error.status||500,{error:error.status?error.message:'Erreur du serveur'});}
 });
 server.requestTimeout=60000;
 server.on('close',()=>db.close());
 return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const server=createServer({database:process.env.DPGAZ_DB||'dpgaz.sqlite',token:process.env.DPGAZ_TOKEN});
 server.listen(Number(process.env.PORT||8787),process.env.HOST||'127.0.0.1',()=>console.log('Serveur DP Gaz démarré.'));
}
